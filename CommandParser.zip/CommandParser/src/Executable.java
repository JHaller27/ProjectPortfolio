/**
 * 01.02.2017
 *
 * @author James
 */
public interface Executable {
    void execute();
}
